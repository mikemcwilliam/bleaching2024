


acroX2 <- c("Acropora...Tabular",  "Acropora...other") #, "Acropora...other", "Isopora"
unique(pit$variable)
acrocov2 <- aggregate(cov~Transect, comp2[comp2$variable %in% acroX2,], sum)
tdf$acro2 <- acrocov2$cov[match(tdf$Transect_code, acrocov2$Transect)]
tdf$acroR2 <- tdf$acro2/tdf$coral_cov
siteac2 <- aggregate(acro2~siteID, tdf, mean)
siteac2$acroR2 <- aggregate(acroR2~siteID, tdf, mean)$acroR2
sites1[,c("acro2", "acroR2")] <- siteac2[match(sites1$siteID, siteac2$siteID),c("acro2", "acroR2") ]
#sites1

geodat <- melt(sites1[sites1$Zone %in% c("Crest"),c("Reef", "GPS.S", "tab", "acro", "acro2", "Region")], id.var=c("Reef", "GPS.S", "Region"))
geodat

geoav <- aggregate(value~Region+variable, geodat, mean)
geoav

plotAc <- c("acro")
geo_ac <- ggplot(geodat[geodat$variable%in% plotAc,], aes(value, reorder(Reef, -GPS.S)))+
#geom_vline(xintercept=6)+
geom_boxplot(size=0.18, outlier.size=0.1, fill="grey80")+
guides(fill="none", col="none")+
geom_segment(data=geoav[geoav$variable %in% plotAc, ], aes(x=value, xend=value, y=-Inf, yend=Inf))+
#scale_fill_manual(values=rcols)+
#scale_fill_viridis(discrete=T, direction=-1)+
#scale_fill_viridis()+
#scale_fill_manual(values=c("grey", "black"))+
#scale_colour_manual(values=c("grey", "black"))+
facet_wrap(~Region, ncol=1, scales="free_y", strip.position="left")+
#scale_x_sqrt()+
theme_classic()+theme(axis.line.y=element_blank(), 
strip.background=element_blank(), 
strip.text.y.left=element_text(size=8, angle=0, hjust=1),
 axis.text.y=element_blank(), axis.ticks=element_blank(),axis.title.x=element_text(size=9), panel.margin.y=unit(2, "mm"), panel.background=element_rect(fill="grey96"))+
labs(y="", x="% Acropora cover\n(2024)")
geo_ac

