
fS1 <- ggplot()+
geom_segment(data=tabmeans, aes(x=-Inf, xend=5.3, y=0, yend=0), col="grey")+
geom_boxplot(data=ssums, aes(as.factor(sumN), betamod), outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
stat_summary(data=tsums, aes(as.factor(sumN), betamod),size=0.25)+
stat_summary(data=tsums, aes(as.factor(sumN), betamod, group=as.factor(n)), geom="line")+
facet_wrap(~Zone)+
coord_cartesian(xlim=c(1,5.7))+
#scale_size_manual(values=c(2,3))+guides(size="none")+
#scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
#geom_text(data=andat[andat$y=="betamod",], aes(x=5.5, y=y4b, label=sig, size=sz, col=as.factor(Nlab)), 
#fontface="bold", hjust=0, show_guide = FALSE)+
labs(x="N events > 6 DHW\n(2016-2023)", y="Bleaching residuals\n(quasibinomial)")+
theme_classic()+theme
fS1


fS1b <- ggplot()+
geom_segment(data=tabmeans, aes(x=-Inf, xend=5.3, y=0, yend=0), col="grey")+
geom_boxplot(data=ssums, aes(as.factor(sumN),gam.5, col=Zone), outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
stat_summary(data=tsums, aes(as.factor(sumN), gam.5, col=Zone),size=0.25)+
stat_summary(data=tsums, aes(as.factor(sumN), gam.5, col=Zone, group=as.factor(n)), geom="line")+
facet_wrap(~Zone)+
coord_cartesian(xlim=c(1,5.7))+
scale_size_manual(values=c(2,3))+guides(size="none")+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
#geom_text(data=andat[andat$y=="gam.5",], aes(x=5.5, y=y4b, label=sig, size=sz,  col=Zone), 
#fontface="bold", hjust=0, show_guide = FALSE)+
labs(x="N events > 6 DHW\n(2016-2023)", y="Bleaching residuals\n(GAM)")+
theme_classic()+theme
fS1b


andat[andat$y=="tab" & andat$Zone=="Crest" & andat$n==4,"y4b"] <- andat[andat$y=="tab" & andat$Zone=="Crest" & andat$n==4,"y4"] +2

andat[andat$y=="tab" & andat$Zone=="Slope" & andat$n==6,"y4b"] <- andat[andat$y=="tab" & andat$Zone=="Slope" & andat$n==6,"y4"] -2

andat[andat$y=="tab" & andat$Zone=="Slope" & andat$n==2,"y4b"] <- andat[andat$y=="tab" & andat$Zone=="Slope" & andat$n==2,"y4"] +2

head(ssums[ssums$Zone=="Crest",])

f2 <- ggplot()+
#geom_segment(data=tabmeans[tabmeans$n==2,], aes(x=-Inf, xend=5.3, y=tab, yend=tab), col="grey")+
geom_boxplot(data=ssums[ssums$Zone=="Crest",], aes(as.factor(sumN),tab), outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"),fill="grey95")+
stat_summary(data=tsums[tsums$Zone=="Crest",], aes(as.factor(sumN), tab, group=1), geom="line")+
stat_summary(data=tsums[tsums$Zone=="Crest",], aes(as.factor(sumN), tab, fill=as.factor(sumN)),size=0.55, shape=21, stroke=0.3)+
#facet_wrap(~Zone)+
#scale_fill_viridis(discrete=T)+
scale_fill_manual(values=c("grey", "#fecc5c", "#fd8d3c", "#e31a1c", "#500000"))+
coord_cartesian(xlim=c(1,5.7))+
guides(fill="none")+
#geom_text(data=andat[andat$y=="tab" & andat$Zone=="Crest",], aes(x=5.5, y=y4b, label=sig), 
#fontface="bold", hjust=0, show_guide = FALSE, size=5)+
labs(x="N events > 6 DHW\n(2016-2023)", y="% Acropora cover (2024)")+
theme_classic()+theme
f2

fS2 <- ggplot()+
geom_segment(data=tabmeans[tabmeans$n==2,], aes(x=-Inf, xend=5.3, y=tab, yend=tab), col="grey")+
geom_boxplot(data=ssums, aes(as.factor(sumN),tab, col=Zone), outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
stat_summary(data=tsums, aes(as.factor(sumN), tab, col=Zone),size=0.25)+
stat_summary(data=tsums, aes(as.factor(sumN), tab, col=Zone, group=as.factor(Zone)), geom="line")+
facet_wrap(~Zone)+
coord_cartesian(xlim=c(1,5.7))+
scale_size_manual(values=c(2,3))+guides(size="none")+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
#geom_text(data=andat[andat$y=="tab",], aes(x=5.5, y=y4b, label=sig, size=sz, col=Zone), 
#fontface="bold", hjust=0, show_guide = FALSE)+
labs(x="N events > 6 DHW\n(2016-2023)", y="% tabular Acropora\n cover (2024)")+
theme_classic()+theme

andat[andat$y=="acro" & andat$Zone=="Crest" & andat$n==2,"y4b"] <- andat[andat$y=="acro" & andat$Zone=="Crest" & andat$n==2,"y4"] -1

andat[andat$y=="acro" & andat$Zone=="Slope" & andat$n==6,"y4b"] <- andat[andat$y=="acro" & andat$Zone=="Slope" & andat$n==6,"y4"] +2 

andat[andat$y=="acro" & andat$Zone=="Crest" & andat$n==6,"y4b"] <- andat[andat$y=="acro" & andat$Zone=="Crest" & andat$n==6,"y4"] +2 



f3 <- ggplot()+
geom_segment(data=NULL, aes(x=-Inf, xend=5.3, y=21.5, yend=21.5), col="grey")+
#geom_boxplot(data=ssums, aes(as.factor(sumN),acro, col=as.factor(Nlab)), outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
stat_summary(data=tsums, aes(as.factor(sumN), acro, col=Zone),size=0.25)+
stat_summary(data=tsums, aes(as.factor(sumN), acro, col=Zone, group=Zone), geom="line")+
#facet_wrap(~Zone)+
coord_cartesian(xlim=c(1,5.7))+
scale_size_manual(values=c(4))+guides(size="none")+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
#geom_text(data=andat1b[andat1b$y=="acro",], aes(x=5.5, y=y4b, label=sig, size=sz), 
#fontface="bold", hjust=0, show_guide = FALSE)+
labs(x="N events > 6 DHW\n(2016-2023)", y="% Acropora cover (2024)")+
theme_classic()+theme
f3

fS3 <- ggplot()+
geom_segment(data=acmeans[acmeans$n==2,], aes(x=-Inf, xend=5.3, y=acro, yend=acro), col="grey")+
geom_boxplot(data=ssums, aes(as.factor(sumN),acro, col=as.factor(Nlab)), outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
stat_summary(data=tsums, aes(as.factor(sumN), acro, col=as.factor(Nlab)),size=0.25)+
stat_summary(data=tsums, aes(as.factor(sumN), acro, col=as.factor(Nlab), group=as.factor(n)), geom="line")+
facet_wrap(~Zone)+
coord_cartesian(xlim=c(1,5.7))+
scale_size_manual(values=c(2,3))+guides(size="none")+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
#geom_text(data=andat[andat$y=="acro",], aes(x=5.5, y=y4b, label=sig, size=sz, col=as.factor(Nlab)), 
#fontface="bold", hjust=0, show_guide = FALSE)+
labs(x="Number of heatwaves\n(2016-2023)", y="% Acropora\n cover (2024)")+
theme_classic()+theme



del <- theme(axis.title.x=element_blank())
del2 <- theme(strip.text=element_blank())

freqplot <- plot_grid(fS1+guides(col="none")+del, 
fS1b+guides(col="none")+del+del2, 
fS2+guides(col="none")+del+del2, 
fS3+guides(col="none")+del2, 
ncol=1, align="v", axis="lr", rel_heights=c(1.1,1,1,1.2))
freqplot


andat2$y4b <- andat2$y4
andat2b$y4b <- andat2b$y4

andat2[andat2$y=="betamod" & andat2$Zone=="Crest" & andat2$n==2,"y4b"] <- andat2[andat2$y=="betamod" & andat2$Zone=="Crest" & andat2$n==2,"y4"] +0.3

andat2[andat2$y=="betamod" & andat2$Zone=="Slope" & andat2$n==2,"y4b"] <- andat2[andat2$y=="betamod" & andat2$Zone=="Slope" & andat2$n==2,"y4"] +0.2

andat2b[andat2b$y=="betamod"  & andat2b$n==2,"y4b"] <- andat2b[andat2b$y=="betamod" & andat2b$n==2,"y4"] -0.1


x1 <- ggplot(lastdat, aes(as.factor(tlast), betamod), shape=21)+
#geom_smooth()+
geom_segment(data=tabmeans2, aes(x=-Inf, xend=4.3, y=0, yend=0), col="grey")+
geom_boxplot(data=slastdat, outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"), fill="grey95")+
#geom_jitter(data=slastdat, aes(tlast, betamod, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
stat_summary(geom="line", aes(group=1))+
stat_summary(size=0.55, shape=21, aes(fill=tlast), stroke=0.3)+
scale_fill_viridis(discrete=T, direction=-1)+
labs(x="Years since last\nevent > 6 DHW", y="Bleaching residuals\n(quasibinomial)")+
#facet_wrap(~Zone)+
guides(fill="none")+
#geom_text(data=andat2b[andat2b$y=="betamod",], aes(x=4.5, y=y4b, label=sig, size=sz), 
#fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(4))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme
x1


xS1 <- ggplot(lastdat, aes(as.factor(tlast), betamod, col=Zone), shape=21)+
#geom_smooth()+
geom_segment(data=tabmeans2, aes(x=-Inf, xend=4.3, y=0, yend=0), col="grey")+
geom_boxplot(data=slastdat, outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
#geom_jitter(data=slastdat, aes(tlast, betamod, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
stat_summary(size=0.25)+
labs(x="Years since last\nevent > 6 DHW", y="Bleaching residuals\n(quasibinomial)")+
stat_summary(geom="line", aes(group=Zone))+
facet_wrap(~Zone)+
#geom_text(data=andat2[andat2$y=="betamod",], aes(x=4.5, y=y4b, label=sig, size=sz), 
#fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,3))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme

andat2[andat2$y=="gam.5" & andat2$Zone=="Crest" & andat2$n==2,"y4b"] <- andat2[andat2$y=="gam.5" & andat2$Zone=="Crest" & andat2$n==2,"y4"] +0.05

andat2[andat2$y=="gam.5" & andat2$Zone=="Slope" & andat2$n==2,"y4b"] <- andat2[andat2$y=="gam.5" & andat2$Zone=="Slope" & andat2$n==2,"y4"] +0.04

andat2[andat2$y=="gam.5" & andat2$Zone=="Crest" & andat2$n==6,"y4b"] <- andat2[andat2$y=="gam.5" & andat2$Zone=="Crest" & andat2$n==6,"y4"] -0.04


x1b <- ggplot(lastdat, aes(as.factor(tlast),gam.5, col=Zone), shape=21)+
#geom_smooth()+
geom_segment(data=tabmeans2, aes(x=-Inf, xend=4.3, y=0, yend=0), col="grey")+
#geom_boxplot(data=slastdat, outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
#geom_jitter(data=slastdat, aes(tlast, betamod, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
stat_summary(size=0.25)+
labs(x="Years since last\nevent > 6 DHW", y="Bleaching residuals\n(GAM)")+
stat_summary(geom="line", aes(group=Zone))+
#geom_text(data=andat2[andat2$y=="gam.5",], aes(x=4.5, y=y4b, label=sig, size=sz, col=Zone), 
#fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,3))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
#facet_wrap(~Zone)+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme

xS1b <- ggplot(lastdat, aes(as.factor(tlast),gam.5, col=Zone), shape=21)+
#geom_smooth()+
geom_segment(data=tabmeans2, aes(x=-Inf, xend=4.3, y=0, yend=0), col="grey")+
geom_boxplot(data=slastdat, outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
#geom_jitter(data=slastdat, aes(tlast, betamod, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
stat_summary(size=0.25)+
labs(x="Years since\nlast heatwave", y="Bleaching residuals\n(GAM)")+
stat_summary(geom="line", aes(group=Zone))+
#geom_text(data=andat2[andat2$y=="gam.5",], aes(x=4.5, y=y4b, label=sig, size=sz, col=Zone), 
#fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,3))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
facet_wrap(~Zone)+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme


andat2[andat2$y=="tab" & andat2$Zone=="Crest" & andat2$n==2,"y4b"] <- andat2[andat2$y=="tab" & andat2$Zone=="Crest" & andat2$n==2,"y4"] -1

andat2[andat2$y=="tab" & andat2$Zone=="Crest" & andat2$n==6,"y4b"] <- andat2[andat2$y=="tab" & andat2$Zone=="Crest" & andat2$n==6,"y4"] +1

andat2[andat2$y=="tab" & andat2$Zone=="Slope" & andat2$n==2,"y4b"] <- andat2[andat2$y=="tab" & andat2$Zone=="Slope" & andat2$n==2,"y4"] +1.5


andat2b[andat2b$y=="tab"  & andat2b$n==2,"y4b"] <- andat2b[andat2b$y=="tab" & andat2b$n==2,"y4"] +1


mean(tabmeans2[tabmeans2$n==2,"tab"])
x2 <- ggplot(lastdat[lastdat$Zone=="Crest",], aes(tlast, tab), shape=21)+
#geom_smooth()+
#geom_segment(data=NULL, aes(x=-Inf, xend=4.3, y=5.4, yend=5.4), col="grey")+
geom_boxplot(data=lastdat[lastdat$Zone=="Crest",],  outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"),fill="grey95")+
#scale_y_sqrt()+
#geom_jitter(data=slastdat, aes(tlast, tab, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
scale_fill_viridis(discrete=T, direction=-1)+
stat_summary(geom="line", aes(group=1))+
guides(fill="none")+
stat_summary(aes(fill=tlast), shape=21, size=0.55, stroke=0.3)+
#facet_wrap(~Zone)+
labs(x="Years since last\nevent > 6 DHW", y="% tabular Acropora")+
#geom_text(data=andat2b[andat2b$y=="tab",], aes(x=4.5, y=y4b, label=sig, size=sz), 
#fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,4))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme
x2

xS2 <- ggplot(lastdat, aes(tlast, tab, col=Zone), shape=21)+
#geom_smooth()+
geom_segment(data=tabmeans2[tabmeans2$n==2,], aes(x=-Inf, xend=4.3, y=tab, yend=tab), col="grey")+
geom_boxplot(data=slastdat,  outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
#scale_y_sqrt()+
#geom_jitter(data=slastdat, aes(tlast, tab, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
stat_summary(size=0.25)+stat_summary(geom="line", aes(group=Zone))+
#facet_wrap(~Zone)+
labs(x="Years since\nlast heatwave", y="% tabular Acropora")+
#geom_text(data=andat2[andat2$y=="tab",], aes(x=4.5, y=y4b, label=sig, size=sz, col=Zone), 
#fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,3))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme

andat2[andat2$y=="acro" & andat2$Zone=="Crest" & andat2$n==2,"y4b"] <- andat2[andat2$y=="acro" & andat2$Zone=="Crest" & andat2$n==2,"y4"] +2


andat2[andat2$y=="acro" & andat2$Zone=="Slope" & andat2$n==2,"y4b"] <- andat2[andat2$y=="acro" & andat2$Zone=="Slope" & andat2$n==2,"y4"] +2

x3 <- ggplot(lastdat, aes(tlast,acro, col=Zone), shape=21)+
#geom_smooth()+
geom_segment(data=acmeans2[acmeans2$n==2,], aes(x=-Inf, xend=4.3, y=acro, yend=acro), col="grey")+
stat_summary(geom="line", aes(group=Zone))+
#scale_fill_manual(values=c("#feb24c", "#de2d26"))+
stat_summary(size=0.25)+
#geom_text(data=andat2[andat2$y=="acro",], aes(x=4.5, y=y4b, label=sig, size=sz, col=Zone), 
fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,3))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
labs(x="Years since\nlast heatwave", y="% Acropora\n cover (2024)")+
#facet_wrap(~Zone)+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme
x3

xS3 <- ggplot(lastdat, aes(tlast,acro, col=Zone), shape=21)+
#geom_smooth()+
geom_segment(data=acmeans2[acmeans2$n==2,], aes(x=-Inf, xend=4.3, y=acro, yend=acro), col="grey")+
geom_boxplot(data=slastdat,  outlier.size=0.05, size=0.1,position = position_dodge2(preserve = "single"))+
#scale_y_sqrt()+
#scale_fill_manual(values=c("white", "black"))+
#geom_jitter(data=slastdat, aes(tlast, acro, col=as.factor(n2), group=as.factor(n2)), shape=21, width=0.1, height=0)+
stat_summary(geom="line", aes(group=Zone))+
#scale_fill_manual(values=c("#feb24c", "#de2d26"))+
stat_summary(size=0.25)+
#geom_text(data=andat2[andat2$y=="acro",], aes(x=4.5, y=y4b, label=sig, size=sz, col=Zone), 
fontface="bold", hjust=0, show_guide = FALSE)+
scale_size_manual(values=c(2,3))+guides(size="none")+
coord_cartesian(xlim=c(1,4.7))+
labs(x="Years since\nlast event > 6 DHW", y="% Acropora\n cover (2024)")+
facet_wrap(~Zone)+
scale_colour_manual(values=c("#feb24c", "#de2d26", "black"))+
theme_classic()+theme
xS3

nrow(sites1)

del <- theme(axis.title.x=element_blank())
del2 <- theme(strip.text=element_blank())
marg <- theme(plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm"))

lastplot <- plot_grid(xS1+guides(col="none")+del, 
xS1b+guides(col="none")+del+del2, 
xS2+guides(col="none")+del+del2, 
xS3+guides(col="none")+del2, 
ncol=1, align="v", axis="lr", rel_heights=c(1.1,1,1,1.2))
lastplot

#plot.margin = unit(c(0.5,0.5,0.5,0.5), "cm")

supfig <- plot_grid(freqplot, lastplot, get_legend(f1), nrow=1, rel_widths=c(1,1,0.5), labels=c("a","b",""))
supfig

pastplot <- plot_grid(
plot_grid(f1+marg+guides(col="none")+del+labs(y="Deviation from expected\nbleaching (2024)"), f2+marg+guides(col="none")+del2, ncol=1, align="v", axis="lr", labels=c("a", "c"), label_size=12),
plot_grid(x1+marg+guides(col="none")+del+labs(y="Deviation from expected\nbleaching (2024)"), x2+marg+guides(col="none")+del2, ncol=1, align="v", axis="lr", labels=c("b", "d"), label_size=12),
nrow=1, rel_widths=c(1,1,0.3))
pastplot

plot_grid(f1+guides(col="none"), f2+guides(col="none"), x1+guides(col="none"), x2+guides(col="none"), nrow=1)





